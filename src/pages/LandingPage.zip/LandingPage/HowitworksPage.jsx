import React from "react";
import Navbar from "./Navbar";
import { Box } from "@mui/material";
import HowitworksPageBody from "./HowitworksPageBody";
import Footer from "./Footer";

const HowitworksPage = () => {
  return (
    <>
      <Box>
        <Navbar />
      </Box>
      <Box
        sx={{
          marginTop: "64px",
        }}
      >
        <HowitworksPageBody/>
      </Box>
      <Box>
        <Footer />
      </Box>
    </>
  )
}

export default HowitworksPage
