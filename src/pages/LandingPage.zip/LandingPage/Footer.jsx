import { Box, Grid, Typography, Button } from "@mui/material";
import React, { useRef } from "react";
import Shoe from "../../assets/shoe5.jfif";
import { useNavigate } from "react-router-dom/dist";
import BxiWhiteLogo from "../../assets/HomePageImages/BXI_WHITE_LOGO.png";
import IRTA_LOGO from "../../assets/HomePageImages/IRTA_LOGO.png";
import FacebookIcon from "@mui/icons-material/Facebook";
import InstagramIcon from "@mui/icons-material/Instagram";
import LinkedInIcon from "@mui/icons-material/LinkedIn";
import TwitterIcon from "@mui/icons-material/Twitter";
import YouTubeIcon from "@mui/icons-material/YouTube";
import fb from "../../assets/HomePageImages/fb.svg";
import { keyframes } from "@emotion/react";
const Footer = () => {
  const navigate = useNavigate();
  const sectionRef = useRef(null);

  const handleClick = () => {
    // Scroll to the target section
    sectionRef.current.scrollIntoView({ behavior: "smooth" });
  };
  const buttonAnimation = keyframes`
  0% {
    transform: scale(1);
  }
  50% {
    transform: scale(1.1);
  }
  100% {
    transform: scale(1);
  }
`;
  return (
    <>
      <Box
        sx={{
          background: "#156DB6",
          marginTop: "10rem",
          padding: "2rem",
        }}
      >
        <Grid container spacing={1}>
          <Grid item xs={12} sm={6} md={2.5}>
            <Box
              sx={{
                alignItems: "center",
                display: "flex",
                flexDirection: "column",
                justifyContent: "center",
              }}
            >
              <Box sx={{}}>
                <img src={BxiWhiteLogo} width={80} alt="BxiWhiteLogo" />
              </Box>

              <Typography
                sx={{
                  ...FooterText,
                  fontWeight: 550,
                  fontSize: "20px",
                  lineHeight: "25px",
                  marginTop: "20px",
                }}
              >
                Pay By Products!
              </Typography>
              <Button
                sx={{
                  background: "#FFFFFF",
                  borderRadius: "32px",
                  width: "162.89px",
                  height: "31.63px",
                  display: "flex",
                  justifyContent: "center",
                  alignItems: "center",
                  marginTop: "20px",
                  boxShadow: "0px 8px 16px rgba(30, 30, 30, 0.5)",
                  "&:hover": {
                    borderRadius: "32px",
                    // border: "2px solid #000 ",
                    background: "#fff",
                    animation: `${buttonAnimation} 1s ease infinite`,
                    display: "flex",
                    alignItems: "center",
                    textAlign: "center",
                  },
                }}
                onClick={() => navigate("/login")}
              >
                <Typography
                  sx={{
                    fontFamily: "Poppins",
                    fontStyle: "normal",
                    fontWeight: 700,
                    fontSize: "11.3315px",
                    lineHeight: "17px",
                    display: "flex",
                    alignItems: "center",
                    textAlign: "center",
                    textTransform: "uppercase",
                    color: "#121136",
                  }}
                >
                  Join Now
                </Typography>
              </Button>
            </Box>
          </Grid>
          <Grid item xs={12} sm={6} md={1.8} xl={2.5} lg={2.5} sx={{ mt: 1 }}>
            <Box>
              <Typography
                sx={{
                  ...FooterText,
                  fontWeight: 550,
                  fontSize: "20px",
                  lineHeight: "35px",
                }}
              >
                Helpful Links
              </Typography>
              <Typography sx={FooterText}>How we work</Typography>
              <Typography sx={FooterText}>About BXI</Typography>
            </Box>
          </Grid>
          <Grid item xs={12} sm={6} md={3.2} xl={3} lg={3} sx={{ mt: 1 }}>
            <Box>
              <Typography
                sx={{
                  ...FooterText,
                  fontWeight: 550,
                  fontSize: "20px",
                  lineHeight: "35px",
                }}
              >
                Barter Exchange of India
              </Typography>
              <Typography sx={FooterText}>PAN: AAXFB2929C </Typography>
              <Typography sx={FooterText}>GST: 27AAXFB2929C1ZA </Typography>
            </Box>
          </Grid>
          <Grid item xs={12} sm={6} md={4.5} xl={4} lg={4} sx={{ mt: 1 }}>
            <Box
              sx={{
                alignItems: "center",
                display: "flex",
                flexDirection: "column",
                justifyContent: "center",
              }}
            >
              <Typography
                sx={{
                  ...FooterText,
                  fontWeight: 550,
                  fontSize: "20px",
                  lineHeight: "35px",
                }}
              >
                “Member of Global Barter Council”
              </Typography>
              <Box sx={{ marginTop: "10px" }}>
                <img
                  src={IRTA_LOGO}
                  style={{ width: "207.68px", height: "86.88px" }}
                  alt="imageAlt"
                />
              </Box>
            </Box>
          </Grid>
        </Grid>
      </Box>
      <Box
        sx={{
          padding: "20px 0",
        }}
      >
        <Grid
          container
          spacing={2}
          sx={{
            display: "flex",
            alignItems: "center",
          }}
        >
          <Grid item xs={12} sm={12} md={4}>
            <Box
              sx={{
                display: "flex",
                justifyContent: "center",
              }}
            >
              <Typography sx={textDesign}>
                @2023 Barter Exchange of India. All Rights Reserved.
              </Typography>
            </Box>
          </Grid>
          <Grid item xs={12} sm={12} md={4}>
            <Box
              sx={{
                display: "flex",
                justifyContent: "center",
              }}
            >
              <Box sx={{ display: "flex", gap: "20px" }}>
                <Box
                  sx={{
                    ...socialIcons,
                  }}
                >
                  {/* <a href="/homepage" target="_blank" rel="noopener noreferrer">
              <FacebookIcon sx={{ color: "#FFFFFF" }} />
            </a> */}
                  <a
                    href=" https://www.facebook.com/bxi.world?mibextid=ZbWKwL"
                    target="_blank"
                    alt="wtsp"
                    style={{
                      color: "inherit",
                      marginTop: "3px",
                    }}
                  >
                    <Box>
                      <FacebookIcon sx={{ color: "fff", background: "fff" }} />
                    </Box>
                  </a>
                </Box>
                <Box sx={socialIcons}>
                  <a
                    href="https://instagram.com/bxi.world?igshid=MzRlODBiNWFlZA== "
                    target="_blank"
                    alt="wtsp"
                    style={{
                      color: "inherit",
                      marginTop: "3px",
                    }}
                  >
                    <Box>
                      <InstagramIcon sx={{ color: "fff", background: "fff" }} />
                    </Box>
                  </a>
                </Box>
                <Box sx={socialIcons}>
                  <a
                    href=" https://www.linkedin.com/company/barter-exchange-of-india/"
                    target="_blank"
                    alt="wtsp"
                    style={{
                      color: "inherit",
                      marginTop: "3px",
                    }}
                  >
                    <Box>
                      <LinkedInIcon sx={{ color: "fff", background: "fff" }} />
                    </Box>
                  </a>
                </Box>
                <Box sx={socialIcons}>
                  <a
                    href="https://twitter.com/bximarketplace?s=20"
                    target="_blank"
                    alt="wtsp"
                    style={{
                      color: "inherit",
                      marginTop: "3px",
                    }}
                  >
                    <Box>
                      <TwitterIcon sx={{ color: "fff", background: "fff" }} />
                    </Box>
                  </a>
                </Box>
                <Box sx={socialIcons}>
                  <a
                    href="https://www.youtube.com/@bxi.world_"
                    target="_blank"
                    alt="wtsp"
                    style={{
                      color: "inherit",
                      marginTop: "3px",
                    }}
                  >
                    <Box>
                      <YouTubeIcon sx={{ color: "fff", background: "fff" }} />
                    </Box>
                  </a>
                </Box>
              </Box>
            </Box>
          </Grid>
          <Grid item xs={12} sm={12} md={4}>
            <Box
              sx={{
                display: "flex",
                justifyContent: "center",
              }}
            >
              <Typography sx={textDesign}>
                Privacy Policy | Terms & Conditions
              </Typography>
            </Box>
          </Grid>
        </Grid>
      </Box>
    </>
  );
};

export default Footer;
const FooterText = {
  fontFamily: "Poppins",
  fontStyle: "normal",
  fontWeight: 400,
  fontSize: "16px",
  lineHeight: "35px",
  textAlign: "left",
  color: "#FFFFFF",
};
const socialIcons = {
  width: "32.39px",
  height: "32.39px",
  background: " #156DB6",
  borderRadius: "50%",
  color: "#FFFFFF",
  display: "flex",
  justifyContent: "center",
  alignItems: "center",
  cursor: "pointer",
  "&:hover": {
    background: "#000",
    transform: "ease 1s",
  },
};
const textDesign = {
  fontFamily: "Poppins",
  fontStyle: "normal",
  fontWeight: 500,
  fontSize: "14px",
  lineHeight: "18px",
  color: "#000000",
};
