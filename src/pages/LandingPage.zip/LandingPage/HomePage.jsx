import React from "react";
import Navbar from "./Navbar";
import LandingPageBody from "./LandingPageBody";
import { Box } from "@mui/material";
import Footer from "./Footer";

const HomePage = () => {
  return (
    <>
      <Box>
        <Navbar />
      </Box>
      <>
        <Box
          sx={{
            marginTop: "64px",
          }}
        >
          <LandingPageBody />
        </Box>
      </>
      <Box>
        <Footer />
      </Box>
    </>
  );
};

export default HomePage;
